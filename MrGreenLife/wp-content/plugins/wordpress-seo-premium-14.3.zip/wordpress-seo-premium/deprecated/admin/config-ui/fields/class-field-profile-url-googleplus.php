<?php
/**
 * WPSEO plugin file.
 *
 * @package WPSEO\Admin\ConfigurationUI
 */

_deprecated_file( __FILE__, 'WPSEO 10.1' );

/**
 * Class WPSEO_Config_Field_Profile_URL_GooglePlus.
 *
 * @deprecated 10.1
 */
class WPSEO_Config_Field_Profile_URL_GooglePlus extends WPSEO_Config_Field {

	/**
	 * WPSEO_Config_Field_Profile_URL_GooglePlus constructor.
	 *
	 * @deprecated 10.1
	 */
	public function __construct() {
		_deprecated_function( __METHOD__, '10.1' );
	}

	/**
	 * Sets adapter.
	 *
	 * @deprecated 10.1
	 *
	 * @param WPSEO_Configuration_Options_Adapter $adapter Adapter to register lookup on.
	 *
	 * @return void
	 */
	public function set_adapter( WPSEO_Configuration_Options_Adapter $adapter ) {
		_deprecated_function( __METHOD__, '10.1' );
	}
}

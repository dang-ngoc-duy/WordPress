<?php
/**
 * WPSEO plugin file.
 *
 * @package WPSEO\Admin\Menu
 */

// Mark this file as deprecated.
_deprecated_file( __FILE__, 'WPSEO 7.0' );

/**
 * Hides submenu items if the advanced settings are not enabled.
 *
 * @deprecated 7.0
 */
class WPSEO_Submenu_Hider {

	/**
	 * Registers all hooks to WordPress.
	 *
	 * @deprecated 7.0
	 *
	 * @return void
	 */
	public function register_hooks() {
		_deprecated_function( __METHOD__, 'WPSEO 7.0' );
	}

	/**
	 * Filters all advanced settings pages from the given pages.
	 *
	 * @deprecated 7.0
	 *
	 * @return void
	 */
	public function filter_settings_pages() {
		_deprecated_function( __METHOD__, 'WPSEO 7.0' );
	}
}
